<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sampledb";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$email1 = mysqli_real_escape_string($conn, $_POST['email']);

$pass1 = mysqli_real_escape_string($conn, $_POST['password']);

session_start();
$_SESSION["uname"] = $email1;




$sql = "SELECT `pwd` FROM `user` WHERE email='$email1'";


if($conn->query($sql)==TRUE){
	
	$result=$conn->query($sql);
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
				if($row['pwd']==$pass1){
					echo "<h3>Logging you in... please wait<h3>";
					$url="dashboardPage.html";
				}
	 
				else{
					echo "<h3>Re-enter Correct password and try again</h3>";
					$url="loginPage.html";
				}
        
			}
	    }

} 
	
else {
    echo "<h3>You must first register to login<h3>";
	$url="registerPage.html";
}
	
	
?>

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="2;url=<?php print $url; ?>">
    <title>aJStore | Login</title>
</head>

<body>
</body>
</html>



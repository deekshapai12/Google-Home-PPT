<?php
session_start();
error_reporting(0);
$server = "fdb14.biz.nf";
$user = "1970304_dacb";
$pass = "zxcv123ZXCV?";
$db = "1970304_dacb";	

$con = mysqli_connect($server,$user,$pass,$db);

if ($con->connect_error) {
	echo "hi";
    die("Connection failed: " . $con->connect_error);
}

$email = mysqli_real_escape_string($con, $_POST['email']);
$password=mysqli_real_escape_string($con, $_POST['password']);
$phone = mysqli_real_escape_string($con, $_POST['phone']);
$city = mysqli_real_escape_string($con, $_POST['city']);
$country=mysqli_real_escape_string($con, $_POST['country']);

$sql = "INSERT INTO `user`(`uid`, `fname`, `lname`, `email`, `pwd`, `phone`, `city`, `gymmaster`, `country`) VALUES ('', '', '', '$email', 'password', '$phone', 'city', '1', '$country');";

if ($con->query($sql) === TRUE) {
    echo "<h3>Registering User... <h3>";
$url="dashboardPage.html";
   } else {
    echo "<h3>UserName Taken or seems like Email/Phone already registered.. Try again <h3>";
$url="loginPage.html";
}


?>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="1;url=<?php print $url; ?>">
    <title>Redirecting...</title>
</head>

<body>
</body>
</html>


